import 'package:flutter/material.dart';

class AttendanceStudent extends StatelessWidget {
  const AttendanceStudent({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}