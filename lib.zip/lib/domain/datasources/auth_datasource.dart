import '../entities/user.dart';

/// Contrato para la fuente de datos de autenticación.
/// Implementaciones: LocalAuthDatasource (demo) y FirebaseAuthDatasource.
abstract class AuthDatasource {
  Future<AppUser> login(String email, String password);

  Future<AppUser> register({
    required String fullName,
    required String code,
    required String email,
    required String password,
    required UserRole role,
  });

  /// Devuelve el usuario con sesión abierta, o null si no hay.
  Future<AppUser?> getCurrentUser();

  Future<void> resetPassword(String email);

  Future<void> logout();
}
