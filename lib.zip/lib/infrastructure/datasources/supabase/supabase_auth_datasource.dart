import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../config/helpers/app_exception.dart';
import '../../../domain/datasources/auth_datasource.dart';
import '../../../domain/entities/user.dart';

import 'package:flutter/foundation.dart';

class SupabaseAuthDatasource implements AuthDatasource {
  SupabaseClient get _client => Supabase.instance.client;

  Future<AppUser> _loadProfile(String uid) async {
    final row = await _client
        .from('users')
        .select()
        .eq('id', uid)
        .maybeSingle();

    if (row == null) {
      await _client.auth.signOut();
      throw const AppException('No se encontró el perfil de tu cuenta.');
    }
    return AppUser(
      id: row['id'] as String,
      fullName: row['full_name'] as String,
      code: row['code'] as String,
      email: row['email'] as String,
      role: row['role'] == 'teacher' ? UserRole.teacher : UserRole.student,
      program: row['program'] as String? ?? 'Programa por definir',
      campus: row['campus'] as String? ?? 'Florencia',
    );
  }

  @override
  Future<AppUser> login(String email, String password) async {
    try {
      final res = await _client.auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );
      return await _loadProfile(res.user!.id);
    } on AuthException catch (e) {
      throw AppException(_authMessage(e.message));
    }
  }

  @override
  Future<AppUser> register({
    required String fullName,
    required String code,
    required String email,
    required String password,
    required UserRole role,
  }) async {
    try {
            try {
        await _client.from('users').insert({
          'id': user.id,
          'full_name': fullName.trim(),
          'code': code.trim(),
          'email': email.trim().toLowerCase(),
          'role': role == UserRole.teacher ? 'teacher' : 'student',
          'program': role == UserRole.teacher
              ? 'Facultad por definir'
              : 'Programa por definir',
          'campus': 'Florencia',
        });
      } on PostgrestException catch (e) {
        await _client.auth.signOut();
        throw AppException(_dbMessage(e));
      }

      return _loadProfile(user.id);
  }

  @override
  Future<AppUser?> getCurrentUser() async {
    final user = _client.auth.currentUser;
    if (user == null) return null;
    return _loadProfile(user.id);
  }

  @override
  Future<void> resetPassword(String email) async {
    try {
      await _client.auth.resetPasswordForEmail(email.trim());
    } on AuthException catch (e) {
      throw AppException(_authMessage(e.message));
    }
  }

  @override
  Future<void> logout() => _client.auth.signOut();

  String _dbMessage(PostgrestException e) {
    if (e.code == '23505') {
      final text = e.message.toLowerCase();
      if (text.contains('code')) return 'Ya existe una cuenta con ese código.';
      if (text.contains('email')) return 'Ya existe una cuenta con ese correo.';
      return 'Ya existe una cuenta con esos datos.';
    }
    if (e.code == '42501') {
      return 'Sin permiso para guardar el perfil. Revisa las políticas (RLS).';
    }
    return 'No se pudo guardar el perfil.';
  }

  String _authMessage(String raw) {
    debugPrint('Auth error: $raw');
    final t = raw.toLowerCase();
    if (t.contains('invalid login')) return 'Correo o contraseña incorrectos.';
    if (t.contains('already registered')) {
      return 'Ya existe una cuenta con ese correo.';
    }
    if (t.contains('not confirmed')) return 'Primero confirma tu correo.';
    if (t.contains('rate limit') || t.contains('too many')) {
      return 'Demasiados intentos. Espera un momento.';
    }
    if (t.contains('password'))
      return 'La contraseña no cumple los requisitos.';
    if (t.contains('clientexception') ||
        t.contains('socket') ||
        t.contains('host lookup') ||
        t.contains('network') ||
        t.contains('fetch')) {
      return 'No se pudo conectar con Supabase. Revisa tu internet y la URL.';
    }
    return 'No se pudo completar la operación.';
  }
}
