import 'package:file_picker/file_picker.dart';

import 'app_exception.dart';
import 'csv_helper.dart';

class StudentImportHelper {
  static const _maxBytes = 2 * 1024 * 1024; // 2 MB

  static Future<StudentImportResult?> pickAndParse() async {
    FilePickerResult? picked;

    try {
      picked = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv', 'txt', 'xls', 'xlsx'],
      );
    } catch (_) {
      throw const AppException('No se pudo abrir el selector de archivos.');
    }

    if (picked == null) return null;

    final file = picked.files.single;
    final extension = (file.extension ?? '').toLowerCase();

    if (extension == 'xls' || extension == 'xlsx') {
      throw const AppException(
        'Los archivos de Excel no se pueden leer directamente. Ábrelo en '
        'Excel, usa "Guardar como" → "CSV UTF-8 (delimitado por comas)" y '
        'sube ese archivo.',
      );
    }

    final bytes = file.bytes;
    if (bytes == null) {
      throw const AppException('No se pudo leer el archivo. Intenta de nuevo.');
    }
    if (bytes.isEmpty) {
      throw const AppException('El archivo está vacío.');
    }
    if (bytes.length > _maxBytes) {
      throw const AppException('El archivo es muy grande (máximo 2 MB).');
    }

    final content = CsvHelper.decodeBytes(bytes);
    final result = CsvHelper.parseStudents(content, file.name);

    if (result.students.isEmpty) {
      final detail = result.problems.isEmpty ? '' : ' ${result.problems.first}';
      throw AppException('No encontré ningún estudiante válido.$detail');
    }

    return result;
  }
}